<?php 
$main_content .= '
<table border="0" cellspacing="1" cellpadding="4" width="100%">
	<tr bgcolor="#505050"><td colspan="1" class="white"><center><b>Informa&ccedil;&otilde;es da Conta</b></center></td></tr>
	<tr bgcolor="#D4C0A1">
		<td>
			Nome: SEUNOME 	<br>
			Banco: SEUBANCO 	<br>
			Conta: SUACONTA 	<br>
			Nº do Banco: NUMBANCO 	<br>
			Agência: AGENCIA <br>
		</td>
		</tr>
	</table>
	';
	?>